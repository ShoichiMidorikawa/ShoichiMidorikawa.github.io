$(document).ready(function(){
 $('.bxslider').bxSlider({
	auto: true,
	mode:'fade',
	pause:4000,
    });
});

$(function() {
  $('#main-menu').smartmenus();
});